package org.fse.mani.controller;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import javax.validation.Valid;

import org.fse.mani.entities.ParentTask;
import org.fse.mani.entities.Task;
import org.fse.mani.model.TaskDTO;
import org.fse.mani.model.response.BaseResponse;
import org.fse.mani.model.response.TaskListResponse;
import org.fse.mani.service.TaskManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://10.140.225.42:8080")
@RequestMapping("/task")
public class TaskController {

	
	private static final String SUCCESS_STATUS = "success";
    private static final String ERROR_STATUS = "error";
    private static final int CODE_SUCCESS = 100;
    private static final int CODE_FAILURE = 102;
	
    
    public TaskManagerService taskManagerService;

    private List<ParentTask> tasks;
    
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
   	private LocalDate startDate;


    @Autowired
    public TaskController(TaskManagerService taskManagerService) {
        this.taskManagerService = taskManagerService;
    }


    @GetMapping("/search")
    public String searchForm() {
    	
        return "search";
    }

    @GetMapping("/saveTask")
    public String saveTask(@ModelAttribute("task") @Valid Task task, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("tasks", tasks);
            return "subject";
        }
        
        
        startDate = LocalDate.of(2019,7,3);
        System.out.println("startDate "+startDate);
    	
        ParentTask parentTask = new ParentTask();
        parentTask.setParent_task("ParentTask1");
        
        task = new Task();
        task.setTask("Task1");
        //task.setParent_task("ParentTask1");
        task.setPriority(10);
        task.setStart_date(startDate);
        task.setEnd_date(startDate);
        
      
        task.setParentTask(parentTask);

        parentTask.setTasks(Collections.singleton(task));
        
        

        taskManagerService.addTask(task);

        return "redirect:/";
    }
    
    
    @GetMapping("/update")
    public BaseResponse update(@ModelAttribute("task") TaskDTO taskDetails){

        BaseResponse baseResponse = null;
        
        	
        taskDetails = new TaskDTO();
        taskDetails.setTaskId(4);
        taskDetails.setTask("abcdefgh");
        taskDetails.setParentTask("parentdeveopment");
        
        boolean isUpdated = taskManagerService.updateTask(taskDetails);

        if(isUpdated){
            baseResponse = new BaseResponse(SUCCESS_STATUS, CODE_SUCCESS);
        } else {
            baseResponse = new BaseResponse(ERROR_STATUS, CODE_FAILURE);
        }

        return baseResponse;
    }
    
    @GetMapping("/deleteTask/{taskId}")
    public BaseResponse deleteBook(@PathVariable("taskId") int taskId){
    	taskManagerService.deleteTask(taskId);
        return new BaseResponse(SUCCESS_STATUS, CODE_SUCCESS);

    }
    
   
    
    @GetMapping("/findAllTasks")
    public TaskListResponse findAllTasks() {
    	System.out.println("findAllTasks called ");
        return (TaskListResponse) taskManagerService.findAllTasks();
    }
    
    
}
