package org.fse.mani.service;

import java.util.List;
import java.util.stream.Collectors;

import org.fse.mani.dao.TaskManagerDao;
import org.fse.mani.entities.ParentTask;
import org.fse.mani.entities.Task;
import org.fse.mani.model.TaskDTO;
import org.fse.mani.model.response.TaskListResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaskManagerSeviceImpl implements TaskManagerService{

    private TaskManagerDao taskManagerDao;

    @Autowired
    public TaskManagerSeviceImpl(TaskManagerDao taskManagerDao) {
        this.taskManagerDao = taskManagerDao;
    }
    
    public void addTask(Task task) {
        taskManagerDao.saveTask(task);
    }
    

	@Override
	public void deleteTask(int taskId) {
		
		taskManagerDao.removeTask(taskId);
		
	}

	@Override
	public TaskListResponse findAllTasks() {
		
		List<Task> allTaskDetails =  taskManagerDao.findAllTasks();
		
		System.out.println("Parent task List Size :"+allTaskDetails.size());
		
		
		for(Task task:allTaskDetails){
			
			System.out.println("TAsk Id "+task.getTask_id());
			System.out.println("Task "+task.getTask());
			System.out.println("task Priority "+task.getPriority());
			System.out.println("Task Start Date "+task.getStart_date());
			System.out.println("Task end date "+task.getEnd_date());
			System.out.println("Parent task Id "+task.getParentTask().getParent_id());
			System.out.println("parent task Name "+task.getParentTask().getParent_task());
		}
		List<TaskDTO> tasks = taskManagerDao.findAllTasks()
                .stream()
                .map(b->new TaskDTO(b.getTask_id(),b.getTask(),b.getParentTask().getParent_id(),b.getParentTask().getParent_task(),b.getPriority(),b.getStart_date(),b.getEnd_date()))
                .collect(Collectors.toList());

        return new TaskListResponse(tasks);
		
		
	}

	@Override
	public boolean updateTask(TaskDTO taskDTO) {

        if(taskDTO.getTaskId()<=0){
            return false;
        }
        
        System.out.println("Task going Update : "+taskDTO.getTaskId());

        Task task = taskManagerDao.findTasksById(taskDTO.getTaskId());
        
        System.out.println("Task Id "+task.getTask_id());
		System.out.println("Task "+task.getTask());
		System.out.println("task Priority "+task.getPriority());
		System.out.println("Task Start Date "+task.getStart_date());
		System.out.println("Task end date "+task.getEnd_date());
		System.out.println("Parent task Id "+task.getParentTask().getParent_id());
		System.out.println("parent task Name "+task.getParentTask().getParent_task());
        
		
		
		ParentTask parentTask = task.getParentTask();
        parentTask.setParent_task(taskDTO.getParentTask());
        
        if(taskDTO.getTask() != null && !"".equals(taskDTO.getTask())){
        	task.setTask(taskDTO.getTask());
        }

        if(taskDTO.getPriority()>=1.00){
        	task.setPriority(taskDTO.getPriority());
        }

        if(taskDTO.getStartDate() != null){
        	task.setStart_date(taskDTO.getStartDate());
        }
        if(taskDTO.getEndDate() != null){
        	task.setEnd_date(taskDTO.getEndDate());
        }
        
        
      
        task.setParentTask(parentTask);

        //parentTask.setTasks(Collections.singleton(task));
		
        Task updartedTask =   taskManagerDao.saveTask(task);

        return updartedTask != null;
    }

	

}
