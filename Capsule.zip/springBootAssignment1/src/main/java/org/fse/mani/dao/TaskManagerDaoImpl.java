package org.fse.mani.dao;


import java.util.List;

import org.fse.mani.entities.Task;
import org.fse.mani.repositories.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class TaskManagerDaoImpl implements TaskManagerDao {
	
    
    private TaskRepository taskRepository;

    @Autowired
    public TaskManagerDaoImpl(TaskRepository taskRepository) {
       
        this.taskRepository = taskRepository;
    }

    
    public Task saveTask(Task task) {
    	
    	return taskRepository.save(task);
    }

	@Override
	public void removeTask(int taskId) {
		
		taskRepository.deleteByTaskId(taskId);
		
	}

	
	@Override
	public List<Task> findAllTasks() {
		// TODO Auto-generated method stub
		return taskRepository.findAll();
	}


	@Override
	public Task findTasksById(int taskId) {
		// TODO Auto-generated method stub
		return taskRepository.findTask(taskId);
	}
}
