package org.fse.mani.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.fse.mani.entities.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TaskRepository extends JpaRepository<Task, Integer> {
    
	Task save(Task task);
    
    List<Task> findAll();
    
    @Query("SELECT tt FROM Task tt WHERE tt.task_id=(:taskId)")
    Task findTask(@Param("taskId") int taskId);
    
    //@Query("DELETE FROM Task WHERE task_id=(:taskId)")
    @Transactional
    @Modifying
    @Query("delete from Task tt where tt.task_id =(:taskId)")
    void deleteByTaskId(@Param("taskId") int task_id);
    
}
