package org.fse.mani.repositories;

import java.util.UUID;

import org.fse.mani.entities.ParentTask;
import org.fse.mani.entities.Task;
import org.springframework.data.repository.Repository;

public interface ParentTaskRepository extends Repository<ParentTask, UUID> {
    /*List<Subject> findAll();
    List<Subject> findBySubtitleIgnoreCaseContaining(String title);
    Subject findById(Long subjectId);
    Subject save(Subject subject);
    void deleteBySubjectId(Long subjectId);*/
    
    Task save(Task task);
    
   // void deleteByTaskId(int task_id);
    
}
