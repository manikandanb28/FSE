package org.fse.mani.model;


import java.io.Serializable;
import java.time.LocalDate;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
public class TaskDTO implements Serializable {
	
	
	

	    @JsonProperty("taskId")
	    private int taskId;
	    
	    private String task;
	    
	    private int parentTaskId;
	    
	    private String parentTask;
		
		private int priority;
		
		@JsonProperty("startDate")
	    @JsonFormat(pattern = "yyyy-MM-dd")
	    @NotNull
		private LocalDate startDate;
		
		@JsonProperty("ebsDate")
	    @JsonFormat(pattern = "yyyy-MM-dd")
	    @NotNull
		private LocalDate endDate;
	  

	    public TaskDTO() {
	    }


		public int getTaskId() {
			return taskId;
		}


		public void setTaskId(int taskId) {
			this.taskId = taskId;
		}


		public String getTask() {
			return task;
		}


		public void setTask(String task) {
			this.task = task;
		}


		public int getParentTaskId() {
			return parentTaskId;
		}


		public void setParentTaskId(int parentTaskId) {
			this.parentTaskId = parentTaskId;
		}


		public String getParentTask() {
			return parentTask;
		}


		public void setParentTask(String parentTask) {
			this.parentTask = parentTask;
		}


		public int getPriority() {
			return priority;
		}


		public void setPriority(int priority) {
			this.priority = priority;
		}


		public LocalDate getStartDate() {
			return startDate;
		}


		public void setStartDate(LocalDate startDate) {
			this.startDate = startDate;
		}


		public LocalDate getEndDate() {
			return endDate;
		}


		public void setEndDate(LocalDate endDate) {
			this.endDate = endDate;
		}

	    public TaskDTO(int taskId,@NotNull String task, int parentTaskId,@NotNull String parentTask, @NotNull @DecimalMin(value = "1.00", message = "Minimum value should be equal or more than 1.00") int priority,@NotNull LocalDate startDate,@NotNull LocalDate endDate) {
	        this.taskId = taskId;
	        this.task = task;	        
	        this.parentTaskId=parentTaskId;
	        this.parentTask=parentTask;
	        this.priority= priority;			
	        this.startDate=startDate;			
	        this.endDate=endDate;
	    }

	  


}
