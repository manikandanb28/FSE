package org.fse.mani.dao;

import java.util.List;

import org.fse.mani.entities.Task;

public interface TaskManagerDao {

    Task saveTask(Task task);
    
    void removeTask(int taskId);    

    List<Task> findAllTasks();
    
    Task findTasksById(int taskId);
    
    
    
    
}
