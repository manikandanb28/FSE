package org.fse.mani.model.response;

import java.util.List;

import org.fse.mani.model.TaskDTO;

public class TaskListResponse {
   
	private List<TaskDTO> tasks;
	
	 public TaskListResponse() {
		 
    }

	public TaskListResponse(List<TaskDTO> tasks) {
    	this.tasks=tasks;
    }

	public List<TaskDTO> getTasks() {
		return tasks;
	}

	public void setTasks(List<TaskDTO> tasks) {
		this.tasks = tasks;
	}

   

    
}
