package org.fse.mani.service;

import org.fse.mani.entities.Task;
import org.fse.mani.model.TaskDTO;
import org.fse.mani.model.response.TaskListResponse;

public interface TaskManagerService {
	
	void addTask(Task task);
	
	boolean updateTask(TaskDTO taskDTO);
	
	void deleteTask(int taskId);
	
	TaskListResponse findAllTasks();
	
	
	
	
	
    
}
